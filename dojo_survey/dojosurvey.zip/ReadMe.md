Was in a giant rush doing this. I am sure code is sloppy, just trying to get 100% caught up. Will come back and polish this up when i have time.
